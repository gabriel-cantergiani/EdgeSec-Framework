package br.pucrio.inf.lac.testlib;

import br.pucrio.inf.lac.ble.BLE;
import br.pucrio.inf.lac.edgesec.EdgeSec;
import br.pucrio.inf.lac.edgesecinterfaces.IAuthenticationPlugin;
import br.pucrio.inf.lac.edgesecinterfaces.ICryptographicPlugin;
import br.pucrio.inf.lac.edgesecinterfaces.ITransportPlugin;
import br.pucrio.inf.lac.hmacmd5authentication.HmacMD5;
import br.pucrio.inf.lac.rc4cryptography.RC4;
import java.util.ArrayList;
import com.polidea.rxandroidble2.RxBleClient;
import android.content.Context;
import android.app.Application;

public class TestClass extends Application{

    public void init() {
        EdgeSec edgeSec = new EdgeSec();
        Context context = getApplicationContext();
        ITransportPlugin blePlugin = new BLE(RxBleClient.create(context));
        ICryptographicPlugin rc4Plugin = new RC4();
        IAuthenticationPlugin hmacMD5Plugin = new HmacMD5();

        String gatewayID = "808DE88FC8TE";
        ArrayList<ICryptographicPlugin> cryptoList = new ArrayList<ICryptographicPlugin>();
        ArrayList<IAuthenticationPlugin> authList = new ArrayList<IAuthenticationPlugin>();
        cryptoList.add(rc4Plugin);
        authList.add(hmacMD5Plugin);

        System.out.println("[DEBUG] Initializing edge sec");
        edgeSec.initialize(gatewayID, blePlugin, cryptoList, authList);

        System.out.println("[DEBUG] Edgesec initialized");

        ArrayList<String> devicesFound = edgeSec.searchDevices();
        System.out.println("[DEBUG] Devices found: " + devicesFound);

        edgeSec.secureConnect(devicesFound.get(0));
    }

    public static void main(String[] args) {
        TestClass testclass = new TestClass();
        testclass.init();
    }
}
